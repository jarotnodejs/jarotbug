// OBEY COMMANDMENTS

global.prefa = ['','!','.',',','🐤','🗿'] //NOT CHANGE
global.owner = ['6285727819741'] //OWNER
global.botname = 'FatalCrash Finix' //BOT NAME
global.versisc = "4.5.0" //NOT CHANGE
global.baileys1 = require('@whiskeysockets/baileys') //NOT CHANGE
global.creator = "Tama_Ultraa" //NOT CHANGE
global.packname = "Sticker By" //OPSIONAL
global.author = "Tama_Ultraa" //OPSIONAL
global.simbol = "!" // SIMBOL MENU